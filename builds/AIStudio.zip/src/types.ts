export interface User {
  id: string;
  name: string;
  email: string;
  roleDescription: string;
  avatarColor: string;
}

export interface TripMember {
  userId: string;
  name: string;
  role: 'creator' | 'member';
  joinedAt: string;
}

export interface TripMoment {
  id: string;
  tripId: string;
  authorId: string;
  authorName: string;
  caption: string;
  placeName?: string;
  imageUrl?: string;
  timestamp: string;
}

export interface Trip {
  id: string;
  name: string;
  destination: string;
  dates: string;
  creatorId: string;
  creatorName: string;
  inviteCode: string; // The unique, reusable invite code
  inviteLink: string; // The full reusable invite URL
  createdAt: string;
  members: TripMember[];
  moments: TripMoment[];
}

export type RefusalReason = 
  | 'invalid_code'
  | 'missing_link'
  | 'not_a_member'
  | 'malformed_link';
