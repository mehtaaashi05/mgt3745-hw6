import React, { useState } from 'react';
import { Trip, User } from '../types.ts';
import { MapPin, Calendar, Users, Copy, Check, Crown, ArrowRight } from 'lucide-react';

interface TripCardProps {
  trip: Trip;
  currentUser: User | null;
  onOpenTrip: (trip: Trip) => void;
}

export const TripCard: React.FC<TripCardProps> = ({
  trip,
  currentUser,
  onOpenTrip,
}) => {
  const [copied, setCopied] = useState(false);

  const isCreator = currentUser && currentUser.id === trip.creatorId;
  const isMember = currentUser && trip.members.some((m) => m.userId === currentUser.id);

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(trip.inviteLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-[#FFFFFF] border-2 border-[#B39051] rounded-[4px] p-6 space-y-4 hover:border-[#051E39] transition-colors">
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
        <div className="space-y-1">
          <div className="text-[18px] font-bold text-[#051E39]">
            {trip.name}
          </div>
          <div className="flex flex-wrap items-center gap-4 text-[14px] text-[#1A1A1A]">
            <span className="flex items-center gap-1">
              <MapPin className="w-4 h-4 text-[#051E39]" />
              {trip.destination}
            </span>
            <span className="flex items-center gap-1">
              <Calendar className="w-4 h-4 text-[#051E39]" />
              {trip.dates}
            </span>
          </div>
        </div>

        <div>
          {isCreator ? (
            <span className="p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#051E39] font-bold flex items-center gap-1">
              <Crown className="w-4 h-4 text-[#051E39]" />
              You're Creator (F2-1)
            </span>
          ) : isMember ? (
            <span className="p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#1A1A1A]">
              Joined Member
            </span>
          ) : (
            <span className="p-2 border border-[#A02020] rounded-[4px] text-[14px] text-[#A02020] font-bold">
              Not a Member
            </span>
          )}
        </div>
      </div>

      {/* Reusable Invite Link Row (F2-3) */}
      <div className="border border-[#B39051] rounded-[4px] p-2 flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-[#FFFFFF]">
        <div className="text-[14px] text-[#1A1A1A] truncate">
          Reusable Invite Code: <strong className="font-mono text-[#051E39]">{trip.inviteCode}</strong>
        </div>
        <button
          type="button"
          onClick={handleCopy}
          className="p-2 border border-[#B39051] rounded-[4px] text-[14px] font-bold text-[#051E39] hover:bg-[#FFFFFF] flex items-center gap-1 shrink-0"
        >
          {copied ? (
            <>
              <Check className="w-4 h-4 text-[#051E39]" />
              <span>Copied Link</span>
            </>
          ) : (
            <>
              <Copy className="w-4 h-4 text-[#051E39]" />
              <span>Copy Invite Link</span>
            </>
          )}
        </button>
      </div>

      {/* Meta Footer */}
      <div className="flex items-center justify-between pt-2 border-t border-[#1A1A1A]/10">
        <div className="flex items-center gap-4 text-[14px] text-[#1A1A1A]/70">
          <span className="flex items-center gap-1">
            <Users className="w-4 h-4 text-[#051E39]" />
            {trip.members.length} {trip.members.length === 1 ? 'member' : 'members'}
          </span>
          <span>{trip.moments.length} moments</span>
        </div>

        <button
          type="button"
          onClick={() => onOpenTrip(trip)}
          className="bg-[#051E39] text-[#FFFFFF] px-6 py-2 rounded-[4px] text-[14px] font-bold hover:bg-[#0a2f57] flex items-center gap-1"
        >
          <span>Open Trip</span>
          <ArrowRight className="w-4 h-4 text-[#FFFFFF]" />
        </button>
      </div>
    </div>
  );
};
