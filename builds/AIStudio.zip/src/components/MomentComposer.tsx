import React, { useState } from 'react';
import { User } from '../types.ts';
import { Camera, MapPin, Send, Image as ImageIcon } from 'lucide-react';

interface MomentComposerProps {
  currentUser: User;
  onPostMoment: (caption: string, placeName?: string, imageUrl?: string) => void;
}

const PHOTO_PRESETS = [
  {
    label: 'Street Food Stall',
    url: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=800&q=80',
  },
  {
    label: 'Scenic Sunset View',
    url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80',
  },
  {
    label: 'Hidden Cafe Corner',
    url: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=800&q=80',
  },
  {
    label: 'Historic Alley',
    url: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=800&q=80',
  },
];

export const MomentComposer: React.FC<MomentComposerProps> = ({
  currentUser,
  onPostMoment,
}) => {
  const [caption, setCaption] = useState('');
  const [placeName, setPlaceName] = useState('');
  const [selectedPhoto, setSelectedPhoto] = useState<string>('');
  const [showPhotoPicker, setShowPhotoPicker] = useState(false);
  const [customPhotoUrl, setCustomPhotoUrl] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!caption.trim()) return;

    const finalPhoto = customPhotoUrl.trim() || selectedPhoto || undefined;
    onPostMoment(caption.trim(), placeName.trim() || undefined, finalPhoto);

    // Reset inline form
    setCaption('');
    setPlaceName('');
    setSelectedPhoto('');
    setCustomPhotoUrl('');
    setShowPhotoPicker(false);
  };

  return (
    <div className="bg-[#FFFFFF] border-2 border-[#B39051] rounded-[4px] p-6 space-y-4">
      <div className="border-b border-[#1A1A1A]/10 pb-2 space-y-1">
        <div className="text-[16px] font-bold text-[#051E39]">
          Share an In-The-Moment Memory
        </div>
        <p className="text-[14px] text-[#1A1A1A]">
          Share what just happened or a spot you loved with your group. Keeps your trip together in one place instead of lost in scattered text threads.
        </p>
      </div>

      {/* Inline Form - Strictly No Modal */}
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Short story / caption */}
        <div className="space-y-2">
          <label className="block text-[14px] font-bold text-[#1A1A1A]">
            What happened or what did you discover?
          </label>
          <textarea
            value={caption}
            onChange={(e) => setCaption(e.target.value)}
            rows={2}
            placeholder="e.g. Found an unmarked 6-seat coffee bar down the alley. You guys have to try the iced latte here!"
            className="w-full p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#1A1A1A] bg-[#FFFFFF] outline-none resize-none"
            required
          />
        </div>

        {/* Place Tag */}
        <div className="space-y-2">
          <label className="block text-[14px] font-bold text-[#1A1A1A] flex items-center gap-2">
            <MapPin className="w-4 h-4 text-[#051E39]" />
            Spot or Place Loved (Optional)
          </label>
          <input
            type="text"
            value={placeName}
            onChange={(e) => setPlaceName(e.target.value)}
            placeholder="e.g. Higashiyama Pottery Alley or Roaster Coffee Bar"
            className="w-full p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#1A1A1A] bg-[#FFFFFF] outline-none"
          />
        </div>

        {/* Photo Selection */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-[14px] font-bold text-[#1A1A1A] flex items-center gap-2">
              <Camera className="w-4 h-4 text-[#051E39]" />
              Attach Photo Moment (Optional)
            </label>
            <button
              type="button"
              onClick={() => setShowPhotoPicker(!showPhotoPicker)}
              className="p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#1A1A1A] hover:bg-[#FFFFFF]"
            >
              {showPhotoPicker ? 'Hide photo options' : 'Choose photo'}
            </button>
          </div>

          {showPhotoPicker && (
            <div className="p-4 border border-[#B39051] rounded-[4px] space-y-4 bg-[#FFFFFF]">
              <div className="text-[14px] font-bold text-[#1A1A1A]">
                Select quick travel snapshot:
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {PHOTO_PRESETS.map((preset) => (
                  <button
                    key={preset.url}
                    type="button"
                    onClick={() => {
                      setSelectedPhoto(preset.url);
                      setCustomPhotoUrl('');
                    }}
                    className={`p-2 border rounded-[4px] text-left space-y-1 ${
                      selectedPhoto === preset.url
                        ? 'border-2 border-[#051E39] bg-[#FFFFFF]'
                        : 'border-[#B39051] hover:bg-[#FFFFFF]'
                    }`}
                  >
                    <img
                      src={preset.url}
                      alt={preset.label}
                      className="w-full h-16 object-cover rounded-[4px]"
                    />
                    <div className="text-[14px] text-[#1A1A1A] truncate">
                      {preset.label}
                    </div>
                  </button>
                ))}
              </div>

              <div className="space-y-2 pt-2 border-t border-[#1A1A1A]/10">
                <label className="block text-[14px] text-[#1A1A1A]">
                  Or paste direct image URL:
                </label>
                <input
                  type="text"
                  value={customPhotoUrl}
                  onChange={(e) => {
                    setCustomPhotoUrl(e.target.value);
                    if (e.target.value) setSelectedPhoto('');
                  }}
                  placeholder="https://example.com/photo.jpg"
                  className="w-full p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#1A1A1A] outline-none"
                />
              </div>
            </div>
          )}

          {/* Photo Preview if selected */}
          {(selectedPhoto || customPhotoUrl) && (
            <div className="flex items-center gap-4 p-2 border border-[#B39051] rounded-[4px]">
              <img
                src={customPhotoUrl || selectedPhoto}
                alt="Moment preview"
                className="w-12 h-12 object-cover rounded-[4px]"
              />
              <span className="text-[14px] text-[#1A1A1A]">Photo attached</span>
              <button
                type="button"
                onClick={() => {
                  setSelectedPhoto('');
                  setCustomPhotoUrl('');
                }}
                className="ml-auto text-[14px] font-bold text-[#A02020] hover:underline"
              >
                Remove
              </button>
            </div>
          )}
        </div>

        {/* Quick moment suggestions */}
        <div className="flex flex-wrap gap-2 pt-2">
          <span className="text-[14px] text-[#1A1A1A]/70 self-center">
            Quick notes:
          </span>
          <button
            type="button"
            onClick={() =>
              setCaption('Best food we’ve had on this trip so far! Adding this spot to our group map.')
            }
            className="p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#1A1A1A] hover:bg-[#FFFFFF]"
          >
            "Best food so far!"
          </button>
          <button
            type="button"
            onClick={() =>
              setCaption('Look at this view right now! Don’t miss stopping by here later this afternoon.')
            }
            className="p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#1A1A1A] hover:bg-[#FFFFFF]"
          >
            "Look at this view!"
          </button>
        </div>

        {/* Post Button */}
        <div className="pt-2 border-t border-[#1A1A1A]/10 flex justify-between items-center">
          <span className="text-[14px] text-[#1A1A1A]">
            Posting as: <strong className="text-[#051E39]">{currentUser.name}</strong>
          </span>
          <button
            type="submit"
            className="bg-[#051E39] text-[#FFFFFF] px-6 py-2 rounded-[4px] text-[14px] font-bold hover:bg-[#0a2f57] flex items-center gap-2"
          >
            <Send className="w-4 h-4 text-[#FFFFFF]" />
            Post Moment
          </button>
        </div>
      </form>
    </div>
  );
};
