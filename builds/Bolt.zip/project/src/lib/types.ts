export type Trip = {
  id: string;
  name: string;
  creator_id: string;
  invite_token: string;
  created_at: string;
};

export type TripMember = {
  trip_id: string;
  user_id: string;
  role: 'creator' | 'member';
  joined_at: string;
  profile?: { email: string };
};
