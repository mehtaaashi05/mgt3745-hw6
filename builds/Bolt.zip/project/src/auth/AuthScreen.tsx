import { useState, type FormEvent } from 'react';
import { supabase } from '@/lib/supabase';

type Mode = 'signin' | 'signup';

function friendlyAuthError(code: string | undefined, fallback: string): string {
  if (!code) return fallback;
  if (code === 'invalid_credentials') return 'Email or password is incorrect.';
  if (code === 'user_already_exists' || code === 'email_exists') return 'That email is already registered. Try signing in instead.';
  if (code === 'weak_password') return 'Please choose a stronger password (at least 6 characters).';
  return fallback;
}

export default function AuthScreen() {
  const [mode, setMode] = useState<Mode>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  function toggle(next: Mode) {
    setMode(next);
    setError(null);
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const trimmedEmail = email.trim();
      if (!trimmedEmail || !password) {
        setError('Please enter your email and password.');
        return;
      }
      if (mode === 'signup') {
        const { error: signUpError } = await supabase.auth.signUp({ email: trimmedEmail, password });
        if (signUpError) throw signUpError;
      } else {
        const { error: signInError } = await supabase.auth.signInWithPassword({ email: trimmedEmail, password });
        if (signInError) throw signInError;
      }
    } catch (cause) {
      const err = cause as { code?: string; message?: string };
      console.error('auth failed', cause);
      setError(friendlyAuthError(err.code, 'Could not complete the request. Please try again.'));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-primary px-4 py-10">
      <div className="w-full max-w-sm bg-background rounded-base border border-accent/40 p-8 shadow-lg">
        <div className="flex flex-col items-center text-center mb-8">
          <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center mb-4">
            <span className="text-accent font-bold text-xl">T</span>
          </div>
          <h1 className="font-heading text-2xl font-bold text-primary">Trip Tales</h1>
          <p className="text-ink/60 mt-2" style={{ fontSize: '14px' }}>
            Create a trip and invite your friends to come along.
          </p>
        </div>

        <form onSubmit={onSubmit} className="flex flex-col gap-4" noValidate>
          <label className="flex flex-col gap-1">
            <span className="text-ink font-medium" style={{ fontSize: '14px' }}>Email</span>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="rounded-base border border-ink/20 px-3 py-2 text-ink focus:border-accent focus:outline-none"
              style={{ fontSize: '16px' }}
              autoComplete="email"
              required
            />
          </label>
          <label className="flex flex-col gap-1">
            <span className="text-ink font-medium" style={{ fontSize: '14px' }}>Password</span>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="rounded-base border border-ink/20 px-3 py-2 text-ink focus:border-accent focus:outline-none"
              style={{ fontSize: '16px' }}
              autoComplete={mode === 'signup' ? 'new-password' : 'current-password'}
              required
            />
          </label>

          {error && (
            <p className="text-error" style={{ fontSize: '14px' }} role="alert">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={busy}
            className="mt-2 rounded-base bg-primary text-background py-2.5 font-semibold hover:bg-primary/90 transition-colors disabled:opacity-60"
            style={{ fontSize: '14px' }}
          >
            {busy ? 'Please wait…' : mode === 'signup' ? 'Create account' : 'Sign in'}
          </button>
        </form>

        <p className="text-center text-ink/60 mt-6" style={{ fontSize: '14px' }}>
          {mode === 'signin' ? (
            <>
              New here?{' '}
              <button className="text-primary font-semibold hover:underline" onClick={() => toggle('signup')}>
                Create an account
              </button>
            </>
          ) : (
            <>
              Already have an account?{' '}
              <button className="text-primary font-semibold hover:underline" onClick={() => toggle('signin')}>
                Sign in
              </button>
            </>
          )}
        </p>
      </div>
    </div>
  );
}
