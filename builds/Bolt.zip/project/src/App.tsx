import { useEffect, useState } from 'react';
import { AuthProvider, useAuth } from '@/auth/AuthContext';
import AuthScreen from '@/auth/AuthScreen';
import TripList from '@/trips/TripList';
import TripDetail from '@/trips/TripDetail';
import JoinTrip from '@/trips/JoinTrip';
import { parseInviteToken, clearInviteParam } from '@/lib/api';

function AppInner() {
  const { session, loading } = useAuth();
  const [openTripId, setOpenTripId] = useState<string | null>(null);
  const [inviteToken, setInviteToken] = useState<string | null>(null);

  useEffect(() => {
    setInviteToken(parseInviteToken());
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-ink/50" style={{ fontSize: '14px' }}>Loading…</p>
      </div>
    );
  }

  if (!session) {
    return <AuthScreen />;
  }

  if (inviteToken && !openTripId) {
    return (
      <JoinTrip
        token={inviteToken}
        onJoined={(tripId) => {
          clearInviteParam();
          setInviteToken(null);
          setOpenTripId(tripId);
        }}
        onCancel={() => {
          clearInviteParam();
          setInviteToken(null);
        }}
      />
    );
  }

  if (openTripId) {
    return <TripDetail tripId={openTripId} onBack={() => setOpenTripId(null)} />;
  }

  return <TripList onOpenTrip={setOpenTripId} />;
}

export default function App() {
  return (
    <AuthProvider>
      <AppInner />
    </AuthProvider>
  );
}
