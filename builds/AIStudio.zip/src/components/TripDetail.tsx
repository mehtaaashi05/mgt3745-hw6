import React, { useState } from 'react';
import { Trip, User, TripMoment } from '../types.ts';
import { MomentComposer } from './MomentComposer.tsx';
import {
  MapPin,
  Calendar,
  Users,
  Copy,
  Check,
  Crown,
  Share2,
  ArrowLeft,
  Clock,
  ShieldCheck,
  UserPlus,
} from 'lucide-react';

interface TripDetailProps {
  trip: Trip;
  currentUser: User | null;
  onPostMoment: (caption: string, placeName?: string, imageUrl?: string) => void;
  onGoBack: () => void;
  onSimulateJoinAsFriend: (friendName: string) => void;
}

export const TripDetail: React.FC<TripDetailProps> = ({
  trip,
  currentUser,
  onPostMoment,
  onGoBack,
  onSimulateJoinAsFriend,
}) => {
  const [copied, setCopied] = useState(false);
  const [friendNameInput, setFriendNameInput] = useState('');
  const [justCreatedBanner, setJustCreatedBanner] = useState(true);

  const isCreator = currentUser && currentUser.id === trip.creatorId;
  const isMember = currentUser && trip.members.some((m) => m.userId === currentUser.id);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(trip.inviteLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleSimulateAddFriend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!friendNameInput.trim()) return;
    onSimulateJoinAsFriend(friendNameInput.trim());
    setFriendNameInput('');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Return button */}
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={onGoBack}
          className="p-2 border border-[#B39051] rounded-[4px] text-[14px] font-bold text-[#051E39] hover:bg-[#FFFFFF] flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4 text-[#051E39]" />
          <span>Back to All Trips</span>
        </button>

        {isCreator && (
          <span className="p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#051E39] font-bold flex items-center gap-1">
            <Crown className="w-4 h-4 text-[#051E39]" />
            You are the Trip Creator (F2-1)
          </span>
        )}
      </div>

      {/* Main Trip Header Card */}
      <div className="bg-[#FFFFFF] border-2 border-[#B39051] rounded-[4px] p-6 space-y-4">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
          <div className="space-y-2">
            <div className="text-[24px] font-bold text-[#051E39]">
              {trip.name}
            </div>
            <div className="flex flex-wrap items-center gap-4 text-[14px] text-[#1A1A1A]">
              <span className="flex items-center gap-1">
                <MapPin className="w-4 h-4 text-[#051E39]" />
                {trip.destination}
              </span>
              <span className="flex items-center gap-1">
                <Calendar className="w-4 h-4 text-[#051E39]" />
                {trip.dates}
              </span>
              <span className="flex items-center gap-1">
                <Users className="w-4 h-4 text-[#051E39]" />
                {trip.members.length} {trip.members.length === 1 ? 'member' : 'members'}
              </span>
            </div>
          </div>

          <div className="p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#1A1A1A] space-y-1">
            <div className="font-bold text-[#051E39] flex items-center gap-1">
              <Crown className="w-4 h-4 text-[#051E39]" />
              Creator
            </div>
            <div>{trip.creatorName}</div>
          </div>
        </div>

        {/* Reusable Invite Link Showcase (F2-1 & F2-3) */}
        <div className="border-2 border-[#B39051] rounded-[4px] p-4 bg-[#FFFFFF] space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Share2 className="w-5 h-5 text-[#051E39]" />
              <span className="text-[14px] font-bold text-[#051E39]">
                One Reusable Invite Link (Criterion F2-3)
              </span>
            </div>
            <span className="text-[14px] border border-[#B39051] px-2 py-1 rounded-[4px] text-[#1A1A1A]">
              Code: <strong className="font-mono text-[#051E39]">{trip.inviteCode}</strong>
            </span>
          </div>

          <p className="text-[14px] text-[#1A1A1A] leading-relaxed">
            This is the permanent, reusable invite link for <strong>{trip.name}</strong>. Share it via text message with your friends so they can join and view trip moments. Anyone without this link will be refused (F2-2).
          </p>

          {/* Link box with Copy action */}
          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              readOnly
              value={trip.inviteLink}
              className="flex-1 p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#1A1A1A] bg-[#FFFFFF] font-mono outline-none select-all"
            />
            <button
              type="button"
              onClick={handleCopyLink}
              className="bg-[#051E39] text-[#FFFFFF] px-6 py-2 rounded-[4px] text-[14px] font-bold hover:bg-[#0a2f57] flex items-center justify-center gap-2 shrink-0"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-[#FFFFFF]" />
                  <span>Copied to Clipboard!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 text-[#FFFFFF]" />
                  <span>Copy Invite Link</span>
                </>
              )}
            </button>
          </div>

          {/* Direct Simulation for Reviewers */}
          <div className="pt-2 border-t border-[#1A1A1A]/10 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <span className="text-[14px] text-[#1A1A1A]">
              Test friend join with this link:
            </span>
            <form onSubmit={handleSimulateAddFriend} className="flex gap-2">
              <input
                type="text"
                value={friendNameInput}
                onChange={(e) => setFriendNameInput(e.target.value)}
                placeholder="Friend name (e.g. Jordan)"
                className="p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#1A1A1A] outline-none"
              />
              <button
                type="submit"
                className="p-2 border border-[#B39051] rounded-[4px] text-[14px] font-bold text-[#051E39] hover:bg-[#FFFFFF] flex items-center gap-1"
              >
                <UserPlus className="w-4 h-4 text-[#051E39]" />
                Simulate Join
              </button>
            </form>
          </div>
        </div>

        {/* Member Roster */}
        <div className="border-t border-[#1A1A1A]/10 pt-4 space-y-2">
          <div className="text-[14px] font-bold text-[#051E39] flex items-center gap-2">
            <Users className="w-4 h-4 text-[#051E39]" />
            Trip Members ({trip.members.length})
          </div>
          <div className="flex flex-wrap gap-2">
            {trip.members.map((member) => (
              <div
                key={member.userId}
                className="p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#1A1A1A] flex items-center gap-2 bg-[#FFFFFF]"
              >
                <span>{member.name}</span>
                {member.role === 'creator' ? (
                  <span className="text-[14px] font-bold text-[#051E39] border border-[#B39051] px-1 rounded-[4px]">
                    Creator
                  </span>
                ) : (
                  <span className="text-[14px] text-[#1A1A1A]/70">
                    Member
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Moment Composer - Inline submission, Profile 1 experience */}
      {currentUser && (
        <MomentComposer
          currentUser={currentUser}
          onPostMoment={onPostMoment}
        />
      )}

      {/* Moments Stream - Instant render, no decorative animation delays */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="text-[18px] font-bold text-[#051E39]">
            In-The-Moment Travel Stream ({trip.moments.length})
          </div>
          <span className="text-[14px] text-[#1A1A1A]/70">
            Chronological shared feed
          </span>
        </div>

        {trip.moments.length === 0 ? (
          <div className="p-8 border border-[#B39051] rounded-[4px] text-center space-y-2 bg-[#FFFFFF]">
            <div className="text-[16px] font-bold text-[#051E39]">
              No moments shared yet
            </div>
            <p className="text-[14px] text-[#1A1A1A]">
              Be the first to share what funny or worth remembering event happened today!
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {trip.moments.map((moment) => (
              <div
                key={moment.id}
                className="bg-[#FFFFFF] border-2 border-[#B39051] rounded-[4px] p-6 space-y-4"
              >
                {/* Author & Timestamp */}
                <div className="flex items-center justify-between border-b border-[#1A1A1A]/10 pb-2">
                  <div className="space-y-1">
                    <div className="text-[14px] font-bold text-[#051E39]">
                      {moment.authorName}
                      {moment.authorId === trip.creatorId && (
                        <span className="ml-2 text-[14px] font-normal border border-[#B39051] px-1 rounded-[4px] text-[#1A1A1A]">
                          Creator
                        </span>
                      )}
                    </div>
                    {moment.placeName && (
                      <div className="text-[14px] text-[#1A1A1A] flex items-center gap-1">
                        <MapPin className="w-4 h-4 text-[#051E39]" />
                        <span>{moment.placeName}</span>
                      </div>
                    )}
                  </div>

                  <div className="text-[14px] text-[#1A1A1A]/70 flex items-center gap-1">
                    <Clock className="w-4 h-4 text-[#051E39]" />
                    <span>{moment.timestamp}</span>
                  </div>
                </div>

                {/* Caption / Story */}
                <p className="text-[14px] text-[#1A1A1A] leading-relaxed">
                  {moment.caption}
                </p>

                {/* Photo Attachment if present */}
                {moment.imageUrl && (
                  <div className="border border-[#B39051] rounded-[4px] overflow-hidden">
                    <img
                      src={moment.imageUrl}
                      alt={moment.caption}
                      className="w-full max-h-96 object-cover"
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
