import { useEffect, useState } from 'react';
import { useAuth } from '@/auth/AuthContext';
import { fetchTripMembers, buildInviteLink, type MemberRow } from '@/lib/api';
import { supabase } from '@/lib/supabase';
import type { Trip } from '@/lib/types';
import { ArrowLeft, Copy, Check, Users, Crown, Mail } from 'lucide-react';

type Props = {
  tripId: string;
  onBack: () => void;
};

export default function TripDetail({ tripId, onBack }: Props) {
  const { session } = useAuth();
  const [trip, setTrip] = useState<Trip | null>(null);
  const [members, setMembers] = useState<MemberRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const [tripData, memberData] = await Promise.all([
        supabase
          .from('trips')
          .select('id, name, creator_id, invite_token, created_at')
          .eq('id', tripId)
          .maybeSingle()
          .then(({ data, error }) => {
            if (error) throw error;
            return data as Trip | null;
          }),
        fetchTripMembers(tripId),
      ]);
      if (!tripData) {
        setError('You do not have access to this trip.');
        setTrip(null);
      } else {
        setTrip(tripData);
        setMembers(memberData);
      }
    } catch (cause) {
      console.error('load trip failed', cause);
      setError('Could not load this trip. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, [tripId]);

  async function copyLink(link: string) {
    try {
      await navigator.clipboard.writeText(link);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  }

  const isCreator = trip !== null && session !== null && trip.creator_id === session.user.id;
  const inviteLink = trip ? buildInviteLink(trip.invite_token) : '';

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-ink/50" style={{ fontSize: '14px' }}>Loading trip…</p>
      </div>
    );
  }

  if (error || !trip) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4">
        <p className="text-error mb-4" style={{ fontSize: '14px' }} role="alert">
          {error ?? 'Trip not found.'}
        </p>
        <button
          onClick={onBack}
          className="rounded-base bg-primary text-background px-4 py-2 font-semibold hover:bg-primary/90"
          style={{ fontSize: '14px' }}
        >
          Back to trips
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-background">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 py-4 flex items-center gap-3">
          <button
            onClick={onBack}
            className="text-background/90 hover:text-background flex items-center gap-1"
            style={{ fontSize: '14px' }}
          >
            <ArrowLeft className="w-4 h-4" /> Trips
          </button>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
        <h1 className="font-heading text-2xl font-bold text-primary mb-1">{trip.name}</h1>
        <p className="text-ink/60 mb-8" style={{ fontSize: '14px' }}>
          {isCreator ? 'You created this trip.' : 'You are a member of this trip.'}
        </p>

        <section className="mb-10">
          <h2 className="font-heading font-semibold text-primary mb-3 flex items-center gap-2" style={{ fontSize: '16px' }}>
            <Users className="w-4 h-4 text-accent" /> Invite link
          </h2>
          <div className="rounded-base border border-accent/40 bg-accent/5 px-4 py-4">
            <p className="text-ink/70 mb-3" style={{ fontSize: '14px' }}>
              Share this link with friends so they can join the trip.
            </p>
            <div className="flex flex-col sm:flex-row gap-2 items-stretch sm:items-center">
              <input
                readOnly
                value={inviteLink}
                className="flex-1 rounded-base border border-ink/20 px-3 py-2 text-ink bg-background"
                style={{ fontSize: '14px' }}
                onFocus={(e) => e.currentTarget.select()}
              />
              <button
                onClick={() => copyLink(inviteLink)}
                className="rounded-base border border-accent text-primary px-4 py-2 font-semibold flex items-center justify-center gap-2 hover:bg-accent/10 transition-colors"
                style={{ fontSize: '14px' }}
              >
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                {copied ? 'Copied' : 'Copy link'}
              </button>
            </div>
          </div>
        </section>

        <section>
          <h2 className="font-heading font-semibold text-primary mb-3" style={{ fontSize: '16px' }}>
            Members ({members.length})
          </h2>
          {members.length === 0 ? (
            <p className="text-ink/50" style={{ fontSize: '14px' }}>No members to show.</p>
          ) : (
            <ul className="grid gap-2">
              {members.map((m) => (
                <li
                  key={`${m.trip_id}-${m.user_id}`}
                  className="rounded-base border border-ink/10 px-4 py-3 flex items-center gap-3"
                >
                  <div className="w-9 h-9 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                    <Mail className="w-4 h-4 text-accent" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-ink truncate" style={{ fontSize: '14px' }}>{m.email}</p>
                    <p className="text-ink/50" style={{ fontSize: '14px' }}>
                      Joined {new Date(m.joined_at).toLocaleDateString()}
                    </p>
                  </div>
                  {m.role === 'creator' && (
                    <span className="flex items-center gap-1 text-accent font-semibold" style={{ fontSize: '14px' }}>
                      <Crown className="w-4 h-4" /> Creator
                    </span>
                  )}
                </li>
              ))}
            </ul>
          )}
        </section>
      </main>
    </div>
  );
}
