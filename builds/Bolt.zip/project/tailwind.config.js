/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: '#051E39',
        accent: '#B39051',
        background: '#FFFFFF',
        ink: '#1A1A1A',
        error: '#A02020',
      },
      fontFamily: {
        body: ['Arial', 'sans-serif'],
        heading: ['Arial', 'sans-serif'],
      },
      borderRadius: {
        base: '4px',
      },
      spacing: {
        '8': '2rem',
      },
    },
  },
  plugins: [],
};
