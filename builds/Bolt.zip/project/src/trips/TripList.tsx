import { useEffect, useState } from 'react';
import { useAuth } from '@/auth/AuthContext';
import { fetchMyTrips, createTrip, buildInviteLink } from '@/lib/api';
import type { Trip } from '@/lib/types';
import { Plus, LogOut, Copy, Check, MapPin } from 'lucide-react';

type Props = {
  onOpenTrip: (tripId: string) => void;
};

export default function TripList({ onOpenTrip }: Props) {
  const { session, signOut } = useAuth();
  const [trips, setTrips] = useState<Trip[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [newName, setNewName] = useState('');
  const [creating, setCreating] = useState(false);
  const [createdLink, setCreatedLink] = useState<{ name: string; link: string } | null>(null);
  const [copied, setCopied] = useState(false);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      setTrips(await fetchMyTrips());
    } catch (cause) {
      console.error('load trips failed', cause);
      setError('Could not load your trips. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    const name = newName.trim();
    if (!name) return;
    setCreating(true);
    setError(null);
    try {
      const trip = await createTrip(name);
      setNewName('');
      setCreatedLink({ name: trip.name, link: buildInviteLink(trip.invite_token) });
      setCopied(false);
      await load();
    } catch (cause) {
      console.error('create trip failed', cause);
      setError('Could not create the trip. Please try again.');
    } finally {
      setCreating(false);
    }
  }

  async function copyLink(link: string) {
    try {
      await navigator.clipboard.writeText(link);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-background">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-accent" />
            <span className="font-heading font-bold" style={{ fontSize: '18px' }}>Trip Tales</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-background/70" style={{ fontSize: '14px' }}>
              {session?.user?.email ?? ''}
            </span>
            <button
              onClick={signOut}
              className="flex items-center gap-1 text-background/90 hover:text-background"
              style={{ fontSize: '14px' }}
            >
              <LogOut className="w-4 h-4" /> Sign out
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
        <section className="mb-8">
          <h1 className="font-heading text-2xl font-bold text-primary mb-1">Your trips</h1>
          <p className="text-ink/60 mb-6" style={{ fontSize: '14px' }}>
            Create a trip and share the invite link with your friends.
          </p>

          <form onSubmit={handleCreate} className="flex flex-col sm:flex-row gap-3 mb-4" noValidate>
            <input
              type="text"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="Trip name (e.g. Weekend in Lisbon)"
              className="flex-1 rounded-base border border-ink/20 px-3 py-2.5 text-ink focus:border-accent focus:outline-none"
              style={{ fontSize: '16px' }}
              maxLength={120}
              disabled={creating}
            />
            <button
              type="submit"
              disabled={creating || !newName.trim()}
              className="rounded-base bg-primary text-background px-5 py-2.5 font-semibold flex items-center justify-center gap-2 hover:bg-primary/90 transition-colors disabled:opacity-60"
              style={{ fontSize: '14px' }}
            >
              <Plus className="w-4 h-4" /> {creating ? 'Creating…' : 'Create trip'}
            </button>
          </form>

          {error && (
            <p className="text-error mb-4" style={{ fontSize: '14px' }} role="alert">
              {error}
            </p>
          )}

          {createdLink && (
            <div className="rounded-base border border-accent/60 bg-accent/5 px-4 py-4 mb-4">
              <p className="text-primary font-semibold mb-2" style={{ fontSize: '14px' }}>
                “{createdLink.name}” is ready. Here is your reusable invite link:
              </p>
              <div className="flex flex-col sm:flex-row gap-2 items-stretch sm:items-center">
                <input
                  readOnly
                  value={createdLink.link}
                  className="flex-1 rounded-base border border-ink/20 px-3 py-2 text-ink bg-background"
                  style={{ fontSize: '14px' }}
                  onFocus={(e) => e.currentTarget.select()}
                />
                <button
                  onClick={() => copyLink(createdLink.link)}
                  className="rounded-base border border-accent text-primary px-4 py-2 font-semibold flex items-center justify-center gap-2 hover:bg-accent/10 transition-colors"
                  style={{ fontSize: '14px' }}
                >
                  {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  {copied ? 'Copied' : 'Copy'}
                </button>
              </div>
              <p className="text-ink/50 mt-2" style={{ fontSize: '14px' }}>
                Anyone with this link can join the trip.
              </p>
            </div>
          )}
        </section>

        <section>
          {loading ? (
            <p className="text-ink/50" style={{ fontSize: '14px' }}>Loading your trips…</p>
          ) : trips.length === 0 ? (
            <div className="rounded-base border border-dashed border-ink/20 px-6 py-10 text-center">
              <p className="text-ink/70 mb-1" style={{ fontSize: '14px' }}>No trips yet.</p>
              <p className="text-ink/50" style={{ fontSize: '14px' }}>Create your first trip above.</p>
            </div>
          ) : (
            <ul className="grid gap-3">
              {trips.map((trip) => (
                <li key={trip.id}>
                  <button
                    onClick={() => onOpenTrip(trip.id)}
                    className="w-full text-left rounded-base border border-ink/10 px-4 py-4 hover:border-accent hover:bg-accent/5 transition-colors"
                  >
                    <div className="flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <p className="font-heading font-semibold text-primary truncate" style={{ fontSize: '16px' }}>
                          {trip.name}
                        </p>
                        <p className="text-ink/50" style={{ fontSize: '14px' }}>
                          Created {new Date(trip.created_at).toLocaleDateString()}
                        </p>
                      </div>
                      <span className="text-accent" style={{ fontSize: '14px' }}>Open →</span>
                    </div>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>
      </main>
    </div>
  );
}
