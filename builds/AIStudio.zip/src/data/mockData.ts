import { User, Trip } from '../types.ts';

export const INITIAL_USERS: User[] = [
  {
    id: 'user_alex',
    name: 'Alex Carter',
    email: 'alex.carter@workmail.com',
    roleDescription: 'Full-time professional & casual traveler (Profile 1)',
    avatarColor: '#051E39',
  },
  {
    id: 'user_sam',
    name: 'Sam Rivera',
    email: 'sam.rivera@friendmail.com',
    roleDescription: 'Close travel friend',
    avatarColor: '#1A1A1A',
  },
  {
    id: 'user_taylor',
    name: 'Taylor Lee',
    email: 'taylor.lee@friendmail.com',
    roleDescription: 'Friend in group text',
    avatarColor: '#051E39',
  },
  {
    id: 'user_jordan',
    name: 'Jordan Vance',
    email: 'jordan.vance@external.com',
    roleDescription: 'Non-member / outsider without invite',
    avatarColor: '#1A1A1A',
  },
];

export const getBaseUrl = (): string => {
  if (typeof window !== 'undefined') {
    return `${window.location.origin}${window.location.pathname}`;
  }
  return 'https://app.triptogether.internal/';
};

export const createInviteLink = (inviteCode: string): string => {
  const base = getBaseUrl();
  return `${base}?invite=${encodeURIComponent(inviteCode)}`;
};

export const INITIAL_TRIPS: Trip[] = [
  {
    id: 'trip_kyoto_2026',
    name: 'Kyoto Autumn Food Tour',
    destination: 'Kyoto, Japan',
    dates: 'Oct 18 - 25, 2026',
    creatorId: 'user_alex',
    creatorName: 'Alex Carter',
    inviteCode: 'KYOTO-FOOD-88',
    inviteLink: createInviteLink('KYOTO-FOOD-88'),
    createdAt: '2026-10-17T10:00:00Z',
    members: [
      {
        userId: 'user_alex',
        name: 'Alex Carter',
        role: 'creator',
        joinedAt: '2026-10-17T10:00:00Z',
      },
      {
        userId: 'user_sam',
        name: 'Sam Rivera',
        role: 'member',
        joinedAt: '2026-10-17T10:15:00Z',
      },
    ],
    moments: [
      {
        id: 'moment_1',
        tripId: 'trip_kyoto_2026',
        authorId: 'user_alex',
        authorName: 'Alex Carter',
        caption: 'Stumbled into an alley with an unmarked 6-seat yakitori grill. Smoke smelled heavenly so we took the last two stools. Unbelievable dinner!',
        placeName: 'Pontocho Alley Hidden Grill',
        imageUrl: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=800&q=80',
        timestamp: 'Today at 7:40 PM',
      },
      {
        id: 'moment_2',
        tripId: 'trip_kyoto_2026',
        authorId: 'user_sam',
        authorName: 'Sam Rivera',
        caption: 'Alex tried ordering matcha soft serve in broken Japanese and the shop lady gifted us extra warabi mochi because he was so polite haha.',
        placeName: 'Higashiyama Sweet Stand',
        imageUrl: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=800&q=80',
        timestamp: 'Today at 3:15 PM',
      },
    ],
  },
];
