import React, { useState } from 'react';
import { User } from '../types.ts';
import { Sparkles, MapPin, Calendar, UserCheck, AlertCircle, ArrowRight } from 'lucide-react';

interface CreateTripFormProps {
  currentUser: User | null;
  onCreateTrip: (name: string, destination: string, dates: string) => void;
  onGoToSignIn: () => void;
}

export const CreateTripForm: React.FC<CreateTripFormProps> = ({
  currentUser,
  onCreateTrip,
  onGoToSignIn,
}) => {
  const [tripName, setTripName] = useState('');
  const [destination, setDestination] = useState('');
  const [dates, setDates] = useState('');
  const [validationError, setValidationError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!currentUser) {
      setValidationError('You must be signed in to create a trip.');
      return;
    }

    if (!tripName.trim()) {
      setValidationError('Please enter a trip name. Trip name is required.');
      return;
    }

    setValidationError(null);
    onCreateTrip(tripName.trim(), destination.trim(), dates.trim());
  };

  if (!currentUser) {
    return (
      <div className="bg-[#FFFFFF] border-2 border-[#A02020] rounded-[4px] p-6 max-w-xl mx-auto space-y-4">
        <div className="flex items-start gap-4">
          <div className="p-2 border border-[#A02020] rounded-[4px] bg-[#FFFFFF]">
            <AlertCircle className="w-6 h-6 text-[#A02020]" />
          </div>
          <div className="space-y-2">
            <div className="text-[18px] font-bold text-[#A02020]">
              Sign-In Required to Create a Trip (F2-1)
            </div>
            <p className="text-[14px] text-[#1A1A1A]">
              Under criterion F2-1, a signed-in person is required to create a trip so they can be designated as its creator and receive its reusable invite link.
            </p>
          </div>
        </div>

        <div className="pt-2 flex justify-end">
          <button
            type="button"
            onClick={onGoToSignIn}
            className="bg-[#051E39] text-[#FFFFFF] px-6 py-2 rounded-[4px] text-[14px] font-bold hover:bg-[#0a2f57]"
          >
            Select Persona / Sign In
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#FFFFFF] border-2 border-[#B39051] rounded-[4px] p-6 max-w-2xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="border-b border-[#1A1A1A]/10 pb-4 space-y-2">
        <div className="text-[20px] font-bold text-[#051E39]">
          Create a Trip & Invite Members (F2-1)
        </div>
        <p className="text-[14px] text-[#1A1A1A]">
          Create a shared trip space for you and your travel companions. As creator, you will immediately receive one reusable invite link to text your friends.
        </p>
      </div>

      {/* Creator Attribution Preview */}
      <div className="p-4 border border-[#B39051] rounded-[4px] bg-[#FFFFFF] flex items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <UserCheck className="w-5 h-5 text-[#051E39]" />
          <span className="text-[14px] text-[#1A1A1A]">
            Trip Creator: <strong className="text-[#051E39]">{currentUser.name}</strong>
          </span>
        </div>
        <span className="text-[14px] border border-[#B39051] px-2 py-1 rounded-[4px] text-[#1A1A1A] font-medium">
          Will be assigned as Creator (F2-1)
        </span>
      </div>

      {/* Error State */}
      {validationError && (
        <div className="border border-[#A02020] rounded-[4px] p-4 flex items-center gap-2 text-[#A02020] bg-[#FFFFFF]">
          <AlertCircle className="w-5 h-5 text-[#A02020] shrink-0" />
          <span className="text-[14px]">{validationError}</span>
        </div>
      )}

      {/* Inline Creation Form - No Modal Interruptions */}
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Trip Name */}
        <div className="space-y-2">
          <label className="block text-[14px] font-bold text-[#1A1A1A]">
            Trip Name <span className="text-[#A02020]">*</span>
          </label>
          <input
            type="text"
            value={tripName}
            onChange={(e) => {
              setTripName(e.target.value);
              if (validationError) setValidationError(null);
            }}
            placeholder="e.g. Kyoto Autumn Food Tour, Banff Ski Weekend"
            className="w-full p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#1A1A1A] bg-[#FFFFFF] outline-none"
            required
          />
          <div className="text-[14px] text-[#1A1A1A]/70">
            A clear name for you and your group.
          </div>
        </div>

        {/* Destination */}
        <div className="space-y-2">
          <label className="block text-[14px] font-bold text-[#1A1A1A] flex items-center gap-2">
            <MapPin className="w-4 h-4 text-[#051E39]" />
            Destination
          </label>
          <input
            type="text"
            value={destination}
            onChange={(e) => setDestination(e.target.value)}
            placeholder="e.g. Kyoto, Japan or Lake Louise, AB"
            className="w-full p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#1A1A1A] bg-[#FFFFFF] outline-none"
          />
        </div>

        {/* Dates */}
        <div className="space-y-2">
          <label className="block text-[14px] font-bold text-[#1A1A1A] flex items-center gap-2">
            <Calendar className="w-4 h-4 text-[#051E39]" />
            Dates or Travel Window
          </label>
          <input
            type="text"
            value={dates}
            onChange={(e) => setDates(e.target.value)}
            placeholder="e.g. Nov 14 - Nov 21, 2026"
            className="w-full p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#1A1A1A] bg-[#FFFFFF] outline-none"
          />
        </div>

        {/* Prompt presets for quick testing */}
        <div className="pt-2 space-y-2">
          <div className="text-[14px] font-bold text-[#1A1A1A]">
            Quick Presets for Testing:
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => {
                setTripName('Amalfi Coast Scenic Drive');
                setDestination('Positano & Capri, Italy');
                setDates('May 2 - 9, 2026');
              }}
              className="p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#1A1A1A] hover:bg-[#FFFFFF]"
            >
              Amalfi Coast Drive
            </button>
            <button
              type="button"
              onClick={() => {
                setTripName('Banff Alpine Hiking Escape');
                setDestination('Banff & Jasper, Canada');
                setDates('July 10 - 16, 2026');
              }}
              className="p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#1A1A1A] hover:bg-[#FFFFFF]"
            >
              Banff Alpine Escape
            </button>
            <button
              type="button"
              onClick={() => {
                setTripName('Mexico City Taco Crawl');
                setDestination('CDMX, Mexico');
                setDates('Nov 20 - 24, 2026');
              }}
              className="p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#1A1A1A] hover:bg-[#FFFFFF]"
            >
              CDMX Taco Crawl
            </button>
          </div>
        </div>

        {/* Submit Button */}
        <div className="pt-4 border-t border-[#1A1A1A]/10 flex justify-end">
          <button
            type="submit"
            className="bg-[#051E39] text-[#FFFFFF] px-8 py-3 rounded-[4px] text-[14px] font-bold hover:bg-[#0a2f57] flex items-center gap-2"
          >
            <span>Create Trip & Generate Reusable Invite Link</span>
            <ArrowRight className="w-4 h-4 text-[#FFFFFF]" />
          </button>
        </div>
      </form>
    </div>
  );
};
