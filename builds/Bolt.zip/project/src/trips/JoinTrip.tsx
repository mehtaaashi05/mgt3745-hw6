import { useState } from 'react';
import { useAuth } from '@/auth/AuthContext';
import { joinTrip } from '@/lib/api';
import { ShieldAlert, ArrowRight } from 'lucide-react';

type Props = {
  token: string;
  onJoined: (tripId: string) => void;
  onCancel: () => void;
};

export default function JoinTrip({ token, onJoined, onCancel }: Props) {
  const { session } = useAuth();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleJoin() {
    setBusy(true);
    setError(null);
    try {
      const tripId = await joinTrip(token);
      onJoined(tripId);
    } catch (cause) {
      console.error('join trip failed', cause);
      setError('This invite link is not valid. We could not add you to the trip.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <div className="w-full max-w-sm rounded-base border border-accent/40 p-8 text-center">
        <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center mx-auto mb-4">
          <ShieldAlert className="w-6 h-6 text-accent" />
        </div>
        <h1 className="font-heading text-xl font-bold text-primary mb-2">Join a trip</h1>
        <p className="text-ink/70 mb-6" style={{ fontSize: '14px' }}>
          {session
            ? 'You have been invited to join a trip. Continue to accept the invite.'
            : 'Sign in first, then you can accept the invite to this trip.'}
        </p>

        {error && (
          <p className="text-error mb-4" style={{ fontSize: '14px' }} role="alert">
            {error}
          </p>
        )}

        <div className="flex flex-col gap-3">
          {session ? (
            <button
              onClick={handleJoin}
              disabled={busy}
              className="rounded-base bg-primary text-background px-5 py-2.5 font-semibold flex items-center justify-center gap-2 hover:bg-primary/90 transition-colors disabled:opacity-60"
              style={{ fontSize: '14px' }}
            >
              {busy ? 'Joining…' : 'Accept invite'}
              {!busy && <ArrowRight className="w-4 h-4" />}
            </button>
          ) : (
            <p className="text-ink/60" style={{ fontSize: '14px' }}>
              Please sign in or create an account to continue.
            </p>
          )}
          <button
            onClick={onCancel}
            className="text-ink/60 hover:text-ink underline"
            style={{ fontSize: '14px' }}
          >
            Not now
          </button>
        </div>
      </div>
    </div>
  );
}
