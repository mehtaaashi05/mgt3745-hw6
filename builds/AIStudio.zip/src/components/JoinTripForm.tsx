import React, { useState } from 'react';
import { User, Trip } from '../types.ts';
import { KeyRound, ShieldAlert, CheckCircle2, ArrowRight } from 'lucide-react';
import { RefusalCard } from './RefusalCard.tsx';

interface JoinTripFormProps {
  currentUser: User | null;
  availableTrips: Trip[];
  onJoinAttempt: (inviteCodeOrUrl: string) => { success: boolean; trip?: Trip; error?: string };
  onSuccessJoin: (trip: Trip) => void;
  onGoToSignIn: () => void;
}

export const JoinTripForm: React.FC<JoinTripFormProps> = ({
  currentUser,
  availableTrips,
  onJoinAttempt,
  onSuccessJoin,
  onGoToSignIn,
}) => {
  const [inviteInput, setInviteInput] = useState('');
  const [refusalState, setRefusalState] = useState<{
    isRefused: boolean;
    attemptedCode?: string;
    errorMessage?: string;
  } | null>(null);

  // Extract invite code whether user entered full URL or bare code
  const extractCode = (raw: string): string => {
    try {
      if (raw.includes('?invite=')) {
        const url = new URL(raw);
        return url.searchParams.get('invite') || raw;
      }
      return raw.trim();
    } catch {
      return raw.trim();
    }
  };

  const handleJoin = (rawTarget: string) => {
    const code = extractCode(rawTarget);
    if (!code) {
      setRefusalState({
        isRefused: true,
        attemptedCode: '',
        errorMessage:
          'No invite link or code was provided. You cannot join a trip without a valid invite link.',
      });
      return;
    }

    const result = onJoinAttempt(code);
    if (result.success && result.trip) {
      setRefusalState(null);
      onSuccessJoin(result.trip);
    } else {
      setRefusalState({
        isRefused: true,
        attemptedCode: code,
        errorMessage:
          result.error ||
          'Invite link is invalid or unrecognized. Access is refused and no trip details will be displayed (F2-2).',
      });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleJoin(inviteInput);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* If Refusal is active, display the F2-2 Refusal Card */}
      {refusalState?.isRefused ? (
        <RefusalCard
          attemptedCode={refusalState.attemptedCode}
          errorMessage={refusalState.errorMessage}
          onRetryWithCode={(code) => {
            setInviteInput(code);
            handleJoin(code);
          }}
          onGoBack={() => setRefusalState(null)}
        />
      ) : (
        <div className="bg-[#FFFFFF] border-2 border-[#B39051] rounded-[4px] p-6 space-y-6">
          {/* Header */}
          <div className="border-b border-[#1A1A1A]/10 pb-4 space-y-2">
            <div className="text-[20px] font-bold text-[#051E39]">
              Join a Trip with Invite Link (F2-2)
            </div>
            <p className="text-[14px] text-[#1A1A1A]">
              Friends join a trip using the one reusable invite link or code shared by the creator. If someone tries to join without a valid invite link, the app refuses and displays zero trip details.
            </p>
          </div>

          {/* Current Signed In User Status */}
          <div className="p-4 border border-[#B39051] rounded-[4px] bg-[#FFFFFF] flex items-center justify-between gap-4">
            <div className="text-[14px] text-[#1A1A1A]">
              Joining as:{' '}
              <strong className="text-[#051E39]">
                {currentUser ? currentUser.name : 'Guest (Sign-in required to join)'}
              </strong>
            </div>
            {!currentUser && (
              <button
                type="button"
                onClick={onGoToSignIn}
                className="text-[14px] font-bold text-[#051E39] underline"
              >
                Sign in first
              </button>
            )}
          </div>

          {/* Inline Form - No Modal Interruption */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <label className="block text-[14px] font-bold text-[#1A1A1A]">
                Paste Reusable Invite Link or Enter Code:
              </label>
              <input
                type="text"
                value={inviteInput}
                onChange={(e) => setInviteInput(e.target.value)}
                placeholder="e.g. KYOTO-FOOD-88 or full link with ?invite=..."
                className="w-full p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#1A1A1A] bg-[#FFFFFF] outline-none"
              />
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                className="bg-[#051E39] text-[#FFFFFF] px-8 py-3 rounded-[4px] text-[14px] font-bold hover:bg-[#0a2f57] flex items-center gap-2"
              >
                <KeyRound className="w-4 h-4 text-[#FFFFFF]" />
                <span>Verify Link & Join Trip</span>
              </button>
            </div>
          </form>

          {/* Test Buttons Section for Immediate Reviewer Testing */}
          <div className="border-t border-[#1A1A1A]/10 pt-4 space-y-4">
            <div className="text-[14px] font-bold text-[#051E39]">
              Acceptance Criteria Quick Test Triggers:
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Positive Test: Valid Invite */}
              <div className="p-4 border border-[#B39051] rounded-[4px] space-y-2">
                <div className="flex items-center gap-2 text-[14px] font-bold text-[#051E39]">
                  <CheckCircle2 className="w-4 h-4 text-[#051E39]" />
                  <span>Valid Link Test (F2-3)</span>
                </div>
                <p className="text-[14px] text-[#1A1A1A]">
                  Test joining with a legitimate reusable trip invite code.
                </p>
                {availableTrips.length > 0 ? (
                  <button
                    type="button"
                    onClick={() => {
                      setInviteInput(availableTrips[0].inviteCode);
                      handleJoin(availableTrips[0].inviteCode);
                    }}
                    className="w-full p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#1A1A1A] hover:bg-[#FFFFFF] font-bold text-left"
                  >
                    Use Code: {availableTrips[0].inviteCode} ({availableTrips[0].name})
                  </button>
                ) : (
                  <div className="text-[14px] text-[#1A1A1A]/70">
                    Create a trip first to generate a valid code.
                  </div>
                )}
              </div>

              {/* Negative Test: F2-2 Refusal */}
              <div className="p-4 border border-[#B39051] rounded-[4px] space-y-2">
                <div className="flex items-center gap-2 text-[14px] font-bold text-[#A02020]">
                  <ShieldAlert className="w-4 h-4 text-[#A02020]" />
                  <span>Invalid Link Test (F2-2 Refusal)</span>
                </div>
                <p className="text-[14px] text-[#1A1A1A]">
                  Tests requirement: App refuses and shows zero trip details.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    const invalidCode = 'FORGED-INVITE-999';
                    setInviteInput(invalidCode);
                    handleJoin(invalidCode);
                  }}
                  className="w-full p-2 border border-[#A02020] rounded-[4px] text-[14px] text-[#1A1A1A] hover:bg-[#FFFFFF] font-bold text-left"
                >
                  Simulate Invalid Link: FORGED-INVITE-999
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
