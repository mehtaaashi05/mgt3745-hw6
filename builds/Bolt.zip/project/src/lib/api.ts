import { supabase } from '@/lib/supabase';
import type { Trip } from '@/lib/types';

export async function fetchMyTrips(): Promise<Trip[]> {
  const { data, error } = await supabase
    .from('trips')
    .select('id, name, creator_id, invite_token, created_at')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data ?? []) as Trip[];
}

export async function createTrip(name: string): Promise<Trip> {
  const { data, error } = await supabase.rpc('create_trip', { p_name: name });
  if (error) throw error;
  return data as Trip;
}

export async function joinTrip(inviteToken: string): Promise<string> {
  const { data, error } = await supabase.rpc('join_trip', { p_invite_token: inviteToken });
  if (error) throw error;
  return data as string;
}

export type MemberRow = {
  trip_id: string;
  user_id: string;
  role: string;
  joined_at: string;
  email: string;
};

export async function fetchTripMembers(tripId: string): Promise<MemberRow[]> {
  const { data, error } = await supabase.rpc('list_trip_members', { p_trip_id: tripId });
  if (error) throw error;
  return (data ?? []) as MemberRow[];
}

export function buildInviteLink(token: string): string {
  return `${window.location.origin}/?invite=${token}`;
}

export function parseInviteToken(): string | null {
  const params = new URLSearchParams(window.location.search);
  return params.get('invite');
}

export function clearInviteParam() {
  const url = new URL(window.location.href);
  url.searchParams.delete('invite');
  window.history.replaceState({}, '', url.toString());
}
