/*
# Revoke PUBLIC execute on trip functions

The default EXECUTE grant to PUBLIC on SECURITY DEFINER functions lets the anon role
call them. Revoke from PUBLIC explicitly, then re-grant to authenticated only.
*/

REVOKE EXECUTE ON FUNCTION create_trip(text) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION join_trip(text) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION list_trip_members(uuid) FROM PUBLIC;

GRANT EXECUTE ON FUNCTION create_trip(text) TO authenticated;
GRANT EXECUTE ON FUNCTION join_trip(text) TO authenticated;
GRANT EXECUTE ON FUNCTION list_trip_members(uuid) TO authenticated;
