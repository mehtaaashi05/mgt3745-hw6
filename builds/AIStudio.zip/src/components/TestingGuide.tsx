import React, { useState } from 'react';
import { CheckCircle2, ShieldAlert, KeyRound, Crown, ChevronDown, ChevronUp } from 'lucide-react';

interface TestingGuideProps {
  onTriggerInvalidInvite: () => void;
  onTriggerValidInvite: () => void;
  onCreateTripTab: () => void;
}

export const TestingGuide: React.FC<TestingGuideProps> = ({
  onTriggerInvalidInvite,
  onTriggerValidInvite,
  onCreateTripTab,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className="bg-[#FFFFFF] border-2 border-[#B39051] rounded-[4px] p-4 space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="p-1 bg-[#051E39] rounded-[4px]">
            <CheckCircle2 className="w-5 h-5 text-[#FFFFFF]" />
          </div>
          <div>
            <div className="text-[14px] font-bold text-[#051E39]">
              Feature Acceptance Criteria Checklist (F2)
            </div>
            <div className="text-[14px] text-[#1A1A1A]">
              Click to view verification triggers for F2-1, F2-2, and F2-3
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setIsExpanded(!isExpanded)}
          className="p-2 border border-[#B39051] rounded-[4px] text-[14px] font-bold text-[#051E39] hover:bg-[#FFFFFF] flex items-center gap-1 self-start sm:self-auto"
        >
          <span>{isExpanded ? 'Hide Criteria' : 'Show Criteria & Triggers'}</span>
          {isExpanded ? (
            <ChevronUp className="w-4 h-4 text-[#051E39]" />
          ) : (
            <ChevronDown className="w-4 h-4 text-[#051E39]" />
          )}
        </button>
      </div>

      {isExpanded && (
        <div className="pt-2 border-t border-[#1A1A1A]/10 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* F2-1 */}
            <div className="p-4 border border-[#B39051] rounded-[4px] space-y-2">
              <div className="flex items-center gap-1 text-[14px] font-bold text-[#051E39]">
                <Crown className="w-4 h-4 text-[#051E39]" />
                <span>F2-1: Creator & Invite Link</span>
              </div>
              <p className="text-[14px] text-[#1A1A1A]">
                When signed in, creating a trip assigns creator status and generates the reusable invite link.
              </p>
              <button
                type="button"
                onClick={onCreateTripTab}
                className="w-full p-2 border border-[#B39051] rounded-[4px] text-[14px] font-bold text-[#051E39] hover:bg-[#FFFFFF]"
              >
                Go to Create Trip (F2-1)
              </button>
            </div>

            {/* F2-2 */}
            <div className="p-4 border border-[#A02020] rounded-[4px] space-y-2">
              <div className="flex items-center gap-1 text-[14px] font-bold text-[#A02020]">
                <ShieldAlert className="w-4 h-4 text-[#A02020]" />
                <span>F2-2: Refusal Guarantee</span>
              </div>
              <p className="text-[14px] text-[#1A1A1A]">
                Trying to join without a valid invite link refuses access and shows zero trip details.
              </p>
              <button
                type="button"
                onClick={onTriggerInvalidInvite}
                className="w-full p-2 border border-[#A02020] rounded-[4px] text-[14px] font-bold text-[#A02020] hover:bg-[#FFFFFF]"
              >
                Trigger Refusal Test (F2-2)
              </button>
            </div>

            {/* F2-3 */}
            <div className="p-4 border border-[#B39051] rounded-[4px] space-y-2">
              <div className="flex items-center gap-1 text-[14px] font-bold text-[#051E39]">
                <KeyRound className="w-4 h-4 text-[#051E39]" />
                <span>F2-3: One Reusable Link</span>
              </div>
              <p className="text-[14px] text-[#1A1A1A]">
                Each trip has exactly one reusable invite link that works for all friends without expiring.
              </p>
              <button
                type="button"
                onClick={onTriggerValidInvite}
                className="w-full p-2 border border-[#B39051] rounded-[4px] text-[14px] font-bold text-[#051E39] hover:bg-[#FFFFFF]"
              >
                Test Reusable Link (F2-3)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
