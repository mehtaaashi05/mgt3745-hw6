/*
# Create trips, trip_members, and invite-join functions

1. New Tables
- `trips`
  - `id` (uuid, primary key)
  - `name` (text, not null) — trip display name
  - `creator_id` (uuid, not null, defaults to auth.uid()) — the signed-in creator
  - `invite_token` (text, unique, not null) — one reusable invite token per trip
  - `created_at` (timestamptz)
- `trip_members`
  - `trip_id` (uuid, references trips, cascade delete)
  - `user_id` (uuid, references auth.users, cascade delete)
  - `role` (text, 'creator' or 'member', default 'member')
  - `joined_at` (timestamptz)
  - primary key (trip_id, user_id)

2. Security
- RLS enabled on both tables.
- trips: SELECT visible to creator or any member. INSERT/UPDATE/DELETE only by creator.
  The invite_token column is visible to members so they can share the reusable link.
- trip_members: SELECT visible to the user themselves or any member of the same trip.
  Direct INSERT/UPDATE/DELETE is denied; membership is added only through the
  SECURITY DEFINER functions below so invite tokens are validated server-side.
- `create_trip(p_name)` SECURITY DEFINER: creates a trip for the signed-in caller,
  adds them as a 'creator' member, and returns the new trip row (including invite_token).
- `join_trip(p_invite_token)` SECURITY DEFINER: validates the token against trips,
  refuses invalid tokens (raises exception, no details leaked), and upserts the caller
  as a 'member'. Returns the trip id so the frontend can navigate to it.
- EXECUTE on both functions revoked from anon, granted to authenticated.

3. Important notes
- F2-1: a signed-in person calls create_trip with a name; they become creator and
  receive the reusable invite_token (link).
- F2-2: join_trip raises on an invalid/missing token; the frontend shows a refusal
  and no trip details.
- F2-3: each trip has exactly one invite_token, generated once at creation and reused.
*/

CREATE TABLE IF NOT EXISTS trips (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  creator_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  invite_token text UNIQUE NOT NULL DEFAULT encode(gen_random_bytes(16), 'hex'),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS trip_members (
  trip_id uuid NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'member' CHECK (role IN ('creator','member')),
  joined_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (trip_id, user_id)
);

ALTER TABLE trips ENABLE ROW LEVEL SECURITY;
ALTER TABLE trip_members ENABLE ROW LEVEL SECURITY;

-- trips policies
DROP POLICY IF EXISTS "trips_select_member" ON trips;
CREATE POLICY "trips_select_member" ON trips FOR SELECT
  TO authenticated USING (
    creator_id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM trip_members
      WHERE trip_members.trip_id = trips.id
        AND trip_members.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "trips_insert_creator" ON trips;
CREATE POLICY "trips_insert_creator" ON trips FOR INSERT
  TO authenticated WITH CHECK (creator_id = auth.uid());

DROP POLICY IF EXISTS "trips_update_creator" ON trips;
CREATE POLICY "trips_update_creator" ON trips FOR UPDATE
  TO authenticated USING (creator_id = auth.uid())
  WITH CHECK (creator_id = auth.uid());

DROP POLICY IF EXISTS "trips_delete_creator" ON trips;
CREATE POLICY "trips_delete_creator" ON trips FOR DELETE
  TO authenticated USING (creator_id = auth.uid());

-- trip_members policies (direct writes denied; managed via SECURITY DEFINER functions)
DROP POLICY IF EXISTS "members_select_related" ON trip_members;
CREATE POLICY "members_select_related" ON trip_members FOR SELECT
  TO authenticated USING (
    user_id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM trip_members tm
      WHERE tm.trip_id = trip_members.trip_id AND tm.user_id = auth.uid()
    )
    OR EXISTS (
      SELECT 1 FROM trips WHERE trips.id = trip_members.trip_id AND trips.creator_id = auth.uid()
    )
  );

-- SECURITY DEFINER: create a trip + creator membership atomically
CREATE OR REPLACE FUNCTION create_trip(p_name text)
RETURNS trips
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_row trips;
BEGIN
  IF p_name IS NULL OR btrim(p_name) = '' THEN
    RAISE EXCEPTION 'Trip name is required';
  END IF;
  IF length(btrim(p_name)) > 120 THEN
    RAISE EXCEPTION 'Trip name is too long';
  END IF;

  INSERT INTO trips (name, creator_id)
  VALUES (btrim(p_name), auth.uid())
  RETURNING * INTO v_row;

  INSERT INTO trip_members (trip_id, user_id, role)
  VALUES (v_row.id, auth.uid(), 'creator');

  RETURN v_row;
END;
$$;

REVOKE EXECUTE ON FUNCTION create_trip(text) FROM anon;
GRANT EXECUTE ON FUNCTION create_trip(text) TO authenticated;

-- SECURITY DEFINER: join a trip via a reusable invite token
CREATE OR REPLACE FUNCTION join_trip(p_invite_token text)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_trip_id uuid;
BEGIN
  IF p_invite_token IS NULL OR btrim(p_invite_token) = '' THEN
    RAISE EXCEPTION 'Invalid invite link';
  END IF;

  SELECT id INTO v_trip_id FROM trips WHERE invite_token = btrim(p_invite_token);
  IF v_trip_id IS NULL THEN
    RAISE EXCEPTION 'Invalid invite link';
  END IF;

  INSERT INTO trip_members (trip_id, user_id, role)
  VALUES (v_trip_id, auth.uid(), 'member')
  ON CONFLICT (trip_id, user_id) DO NOTHING;

  RETURN v_trip_id;
END;
$$;

REVOKE EXECUTE ON FUNCTION join_trip(text) FROM anon;
GRANT EXECUTE ON FUNCTION join_trip(text) TO authenticated;
