/*
# Add member listing function with emails

1. New Functions
- `list_trip_members(p_trip_id uuid)` SECURITY DEFINER: returns trip_id, user_id,
  role, joined_at, and the member's email (joined from auth.users) for a given trip.
  Authorization: the caller must be the creator or a member of the trip, else raises.
- EXECUTE revoked from anon, granted to authenticated.

2. Notes
- auth.users is not readable by the anon/authenticated roles, so emails are exposed
  only through this function after membership is verified server-side.
*/

CREATE OR REPLACE FUNCTION list_trip_members(p_trip_id uuid)
RETURNS TABLE (
  trip_id uuid,
  user_id uuid,
  role text,
  joined_at timestamptz,
  email text
)
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM trip_members tm
    WHERE tm.trip_id = p_trip_id AND tm.user_id = auth.uid()
  ) AND NOT EXISTS (
    SELECT 1 FROM trips t WHERE t.id = p_trip_id AND t.creator_id = auth.uid()
  ) THEN
    RAISE EXCEPTION 'Not a member of this trip';
  END IF;

  RETURN QUERY
  SELECT tm.trip_id, tm.user_id, tm.role, tm.joined_at, u.email
  FROM trip_members tm
  JOIN auth.users u ON u.id = tm.user_id
  WHERE tm.trip_id = p_trip_id
  ORDER BY tm.joined_at ASC;
END;
$$;

REVOKE EXECUTE ON FUNCTION list_trip_members(uuid) FROM anon;
GRANT EXECUTE ON FUNCTION list_trip_members(uuid) TO authenticated;
