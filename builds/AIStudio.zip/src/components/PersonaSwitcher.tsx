import React, { useState } from 'react';
import { User } from '../types.ts';
import { INITIAL_USERS } from '../data/mockData.ts';
import { Users, UserCheck, LogOut, PlusCircle } from 'lucide-react';

interface PersonaSwitcherProps {
  currentUser: User | null;
  onSelectUser: (user: User | null) => void;
}

export const PersonaSwitcher: React.FC<PersonaSwitcherProps> = ({
  currentUser,
  onSelectUser,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [customName, setCustomName] = useState('');

  const handleAddCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customName.trim()) return;
    const newUser: User = {
      id: `user_${Date.now()}`,
      name: customName.trim(),
      email: `${customName.trim().toLowerCase().replace(/\s+/g, '.')}@example.com`,
      roleDescription: 'Custom traveler persona',
      avatarColor: '#051E39',
    };
    onSelectUser(newUser);
    setCustomName('');
    setIsOpen(false);
  };

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 p-2 border border-[#B39051] rounded-[4px] bg-[#FFFFFF] hover:bg-[#FFFFFF] text-[14px] text-[#1A1A1A]"
        aria-label="Switch Persona"
      >
        <Users className="w-4 h-4 text-[#051E39]" />
        <span>
          Signed in as:{' '}
          <strong className="text-[#051E39]">
            {currentUser ? currentUser.name : 'Guest (Not signed in)'}
          </strong>
        </span>
        <span className="text-[14px] font-bold text-[#051E39]">
          {isOpen ? '▲' : '▼'}
        </span>
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-80 bg-[#FFFFFF] border-2 border-[#B39051] rounded-[4px] p-4 shadow-lg z-50 space-y-4">
          <div className="border-b border-[#1A1A1A]/10 pb-2">
            <div className="text-[14px] font-bold text-[#051E39]">
              Switch Profile (Test Multi-User Flow)
            </div>
            <div className="text-[14px] text-[#1A1A1A] pt-1">
              Select a persona to test trip creation, invite links, and refusal rules:
            </div>
          </div>

          <div className="space-y-2">
            {INITIAL_USERS.map((user) => {
              const isSelected = currentUser?.id === user.id;
              return (
                <button
                  key={user.id}
                  type="button"
                  onClick={() => {
                    onSelectUser(user);
                    setIsOpen(false);
                  }}
                  className={`w-full text-left p-2 rounded-[4px] border ${
                    isSelected
                      ? 'border-[#B39051] bg-[#FFFFFF] font-bold'
                      : 'border-[#1A1A1A]/20 hover:border-[#B39051]'
                  } flex items-center justify-between gap-2`}
                >
                  <div className="space-y-1">
                    <div className="text-[14px] text-[#1A1A1A]">
                      {user.name}
                    </div>
                    <div className="text-[14px] text-[#1A1A1A]/70">
                      {user.roleDescription}
                    </div>
                  </div>
                  {isSelected && (
                    <UserCheck className="w-5 h-5 text-[#051E39] shrink-0" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Quick Custom Persona Form */}
          <form onSubmit={handleAddCustom} className="pt-2 border-t border-[#1A1A1A]/10 space-y-2">
            <label className="block text-[14px] font-bold text-[#1A1A1A]">
              Add New Persona:
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={customName}
                onChange={(e) => setCustomName(e.target.value)}
                placeholder="Name (e.g. Morgan)"
                className="flex-1 p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#1A1A1A] outline-none"
              />
              <button
                type="submit"
                className="bg-[#051E39] text-[#FFFFFF] px-4 py-2 rounded-[4px] text-[14px] font-bold hover:bg-[#0a2f57] flex items-center gap-1"
              >
                <PlusCircle className="w-4 h-4 text-[#FFFFFF]" />
                Use
              </button>
            </div>
          </form>

          {/* Sign Out Option to test unauthenticated state */}
          <div className="pt-2 border-t border-[#1A1A1A]/10">
            <button
              type="button"
              onClick={() => {
                onSelectUser(null);
                setIsOpen(false);
              }}
              className="w-full text-left p-2 rounded-[4px] text-[14px] text-[#1A1A1A] hover:bg-[#FFFFFF] border border-[#1A1A1A]/20 hover:border-[#B39051] flex items-center gap-2"
            >
              <LogOut className="w-4 h-4 text-[#051E39]" />
              <span>Sign out / Act as Guest</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
