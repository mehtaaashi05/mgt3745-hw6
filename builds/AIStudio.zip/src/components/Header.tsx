import React from 'react';
import { User } from '../types.ts';
import { PersonaSwitcher } from './PersonaSwitcher.tsx';
import { Compass, Plus, KeyRound, RotateCcw } from 'lucide-react';

interface HeaderProps {
  currentUser: User | null;
  onSelectUser: (user: User | null) => void;
  activeTab: 'trips' | 'create' | 'join';
  onNavigate: (tab: 'trips' | 'create' | 'join') => void;
  onResetData: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  onSelectUser,
  activeTab,
  onNavigate,
  onResetData,
}) => {
  return (
    <header className="bg-[#FFFFFF] border-b-2 border-[#B39051]">
      <div className="max-w-6xl mx-auto px-4 py-4 space-y-4">
        {/* Top row: Brand & Persona Switcher */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-2 bg-[#051E39] text-[#FFFFFF] rounded-[4px]">
              <Compass className="w-6 h-6 text-[#FFFFFF]" />
            </div>
            <div>
              <div className="text-[20px] font-bold text-[#051E39] tracking-tight">
                TripTogether
              </div>
              <div className="text-[14px] text-[#1A1A1A]">
                Create trips & invite members (F2)
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <PersonaSwitcher
              currentUser={currentUser}
              onSelectUser={onSelectUser}
            />
            <button
              type="button"
              onClick={onResetData}
              title="Reset data to initial state"
              className="p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#1A1A1A] hover:bg-[#FFFFFF] flex items-center gap-1"
            >
              <RotateCcw className="w-4 h-4 text-[#051E39]" />
              <span className="hidden md:inline">Reset Data</span>
            </button>
          </div>
        </div>

        {/* Navigation bar - inline multi-action */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-[#1A1A1A]/10">
          <button
            type="button"
            onClick={() => onNavigate('trips')}
            className={`px-4 py-2 rounded-[4px] text-[14px] font-bold flex items-center gap-2 border ${
              activeTab === 'trips'
                ? 'bg-[#051E39] text-[#FFFFFF] border-[#051E39]'
                : 'bg-[#FFFFFF] text-[#1A1A1A] border-[#B39051] hover:bg-[#FFFFFF]'
            }`}
          >
            <Compass className="w-4 h-4" />
            My Trips
          </button>

          <button
            type="button"
            onClick={() => onNavigate('create')}
            className={`px-4 py-2 rounded-[4px] text-[14px] font-bold flex items-center gap-2 border ${
              activeTab === 'create'
                ? 'bg-[#051E39] text-[#FFFFFF] border-[#051E39]'
                : 'bg-[#FFFFFF] text-[#1A1A1A] border-[#B39051] hover:bg-[#FFFFFF]'
            }`}
          >
            <Plus className="w-4 h-4" />
            Create a Trip (F2-1)
          </button>

          <button
            type="button"
            onClick={() => onNavigate('join')}
            className={`px-4 py-2 rounded-[4px] text-[14px] font-bold flex items-center gap-2 border ${
              activeTab === 'join'
                ? 'bg-[#051E39] text-[#FFFFFF] border-[#051E39]'
                : 'bg-[#FFFFFF] text-[#1A1A1A] border-[#B39051] hover:bg-[#FFFFFF]'
            }`}
          >
            <KeyRound className="w-4 h-4" />
            Join Trip with Invite Link (F2-2)
          </button>
        </div>
      </div>
    </header>
  );
};
