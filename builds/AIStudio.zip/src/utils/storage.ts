import { Trip, User, TripMoment } from '../types.ts';
import { INITIAL_TRIPS, INITIAL_USERS, createInviteLink } from '../data/mockData.ts';

const STORAGE_KEY_TRIPS = 'triptogether_trips_v1';
const STORAGE_KEY_USER = 'triptogether_current_user_v1';

export const loadStoredTrips = (): Trip[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_TRIPS);
    if (!raw) {
      saveStoredTrips(INITIAL_TRIPS);
      return INITIAL_TRIPS;
    }
    const trips = JSON.parse(raw) as Trip[];
    // Ensure all trips have active inviteLink based on current window location
    return trips.map(t => ({
      ...t,
      inviteLink: createInviteLink(t.inviteCode),
    }));
  } catch {
    return INITIAL_TRIPS;
  }
};

export const saveStoredTrips = (trips: Trip[]): void => {
  try {
    localStorage.setItem(STORAGE_KEY_TRIPS, JSON.stringify(trips));
  } catch (err) {
    console.error('Failed to save trips to local storage', err);
  }
};

export const loadCurrentUser = (): User | null => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_USER);
    if (!raw) {
      // Default to Alex Carter (Profile 1)
      const defaultUser = INITIAL_USERS[0];
      saveCurrentUser(defaultUser);
      return defaultUser;
    }
    return JSON.parse(raw) as User;
  } catch {
    return INITIAL_USERS[0];
  }
};

export const saveCurrentUser = (user: User | null): void => {
  try {
    if (!user) {
      localStorage.removeItem(STORAGE_KEY_USER);
    } else {
      localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(user));
    }
  } catch (err) {
    console.error('Failed to save current user', err);
  }
};

// Generate clean reusable invite code
export const generateInviteCode = (tripName: string): string => {
  const cleanPrefix = tripName
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, '')
    .slice(0, 6) || 'TRIP';
  const randomSuffix = Math.floor(1000 + Math.random() * 9000);
  return `${cleanPrefix}-${randomSuffix}`;
};

export const createNewTrip = (
  name: string,
  destination: string,
  dates: string,
  creator: User
): Trip => {
  const tripId = `trip_${Date.now()}`;
  const inviteCode = generateInviteCode(name);
  const inviteLink = createInviteLink(inviteCode);
  const now = new Date().toISOString();

  const newTrip: Trip = {
    id: tripId,
    name: name.trim(),
    destination: destination.trim() || 'Undisclosed Destination',
    dates: dates.trim() || 'Upcoming dates',
    creatorId: creator.id,
    creatorName: creator.name,
    inviteCode,
    inviteLink,
    createdAt: now,
    members: [
      {
        userId: creator.id,
        name: creator.name,
        role: 'creator',
        joinedAt: now,
      },
    ],
    moments: [],
  };

  const existingTrips = loadStoredTrips();
  const updatedTrips = [newTrip, ...existingTrips];
  saveStoredTrips(updatedTrips);
  return newTrip;
};

export interface JoinTripResult {
  success: boolean;
  trip?: Trip;
  error?: string;
}

export const joinTripWithCode = (
  inviteCode: string,
  currentUser: User | null
): JoinTripResult => {
  const trimmed = inviteCode.trim();
  if (!trimmed) {
    return {
      success: false,
      error: 'No invite code provided. A valid invite link or code is required to join a trip.',
    };
  }

  const trips = loadStoredTrips();
  // Case-insensitive match on invite code
  const targetTrip = trips.find(
    t => t.inviteCode.toUpperCase() === trimmed.toUpperCase()
  );

  if (!targetTrip) {
    return {
      success: false,
      error: 'Invalid invite link. The trip does not exist or the link was altered. Access is refused and no trip details will be displayed.',
    };
  }

  if (!currentUser) {
    return {
      success: false,
      error: 'You must be signed in to join this trip with your invite link.',
    };
  }

  // If already a member
  const isMember = targetTrip.members.some(m => m.userId === currentUser.id);
  if (!isMember) {
    const updatedMembers = [
      ...targetTrip.members,
      {
        userId: currentUser.id,
        name: currentUser.name,
        role: 'member' as const,
        joinedAt: new Date().toISOString(),
      },
    ];
    targetTrip.members = updatedMembers;
    const updatedTrips = trips.map(t => (t.id === targetTrip.id ? targetTrip : t));
    saveStoredTrips(updatedTrips);
  }

  return {
    success: true,
    trip: targetTrip,
  };
};

export const addMomentToTrip = (
  tripId: string,
  author: User,
  caption: string,
  placeName?: string,
  imageUrl?: string
): TripMoment => {
  const trips = loadStoredTrips();
  const trip = trips.find(t => t.id === tripId);
  if (!trip) throw new Error('Trip not found');

  const moment: TripMoment = {
    id: `moment_${Date.now()}`,
    tripId,
    authorId: author.id,
    authorName: author.name,
    caption: caption.trim(),
    placeName: placeName?.trim() || undefined,
    imageUrl: imageUrl?.trim() || undefined,
    timestamp: 'Just now',
  };

  trip.moments = [moment, ...trip.moments];
  saveStoredTrips(trips);
  return moment;
};

export const resetToSeedData = (): { trips: Trip[]; user: User } => {
  saveStoredTrips(INITIAL_TRIPS);
  saveCurrentUser(INITIAL_USERS[0]);
  return { trips: INITIAL_TRIPS, user: INITIAL_USERS[0] };
};
