import React, { useState, useEffect } from 'react';
import { Trip, User } from './types.ts';
import {
  loadStoredTrips,
  saveStoredTrips,
  loadCurrentUser,
  saveCurrentUser,
  createNewTrip,
  joinTripWithCode,
  addMomentToTrip,
  resetToSeedData,
} from './utils/storage.ts';
import { Header } from './components/Header.tsx';
import { TripCard } from './components/TripCard.tsx';
import { CreateTripForm } from './components/CreateTripForm.tsx';
import { JoinTripForm } from './components/JoinTripForm.tsx';
import { TripDetail } from './components/TripDetail.tsx';
import { RefusalCard } from './components/RefusalCard.tsx';
import { TestingGuide } from './components/TestingGuide.tsx';
import { Compass, Plus, KeyRound, ShieldAlert, Sparkles } from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(() => loadCurrentUser());
  const [trips, setTrips] = useState<Trip[]>(() => loadStoredTrips());
  const [activeTab, setActiveTab] = useState<'trips' | 'create' | 'join' | 'detail' | 'refusal'>('trips');
  const [selectedTripId, setSelectedTripId] = useState<string | null>(null);
  const [refusalData, setRefusalData] = useState<{
    attemptedCode?: string;
    errorMessage?: string;
  } | null>(null);

  // Check URL params on initial load for direct invite link clicks (?invite=CODE)
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const params = new URLSearchParams(window.location.search);
    const inviteParam = params.get('invite');

    if (inviteParam) {
      handleJoinAttempt(inviteParam);
    }
  }, []);

  const handleSelectUser = (user: User | null) => {
    setCurrentUser(user);
    saveCurrentUser(user);

    // If currently viewing a trip details, verify if the new user is a member
    if (activeTab === 'detail' && selectedTripId) {
      const currentTrip = trips.find((t) => t.id === selectedTripId);
      if (currentTrip && user) {
        const isMember = currentTrip.members.some((m) => m.userId === user.id);
        if (!isMember) {
          // Rule F2-2: Not a member and no valid invite link -> refuse and show no trip details!
          setRefusalData({
            attemptedCode: 'Direct Access without Invite',
            errorMessage: `Access Refused: ${user.name} is not a member of "${currentTrip.name}" and did not join using a valid invite link. Trip details are hidden.`,
          });
          setActiveTab('refusal');
        }
      }
    }
  };

  const handleCreateTrip = (name: string, destination: string, dates: string) => {
    if (!currentUser) return;
    const newTrip = createNewTrip(name, destination, dates, currentUser);
    const updatedTrips = loadStoredTrips();
    setTrips(updatedTrips);
    setSelectedTripId(newTrip.id);
    setActiveTab('detail');
  };

  const handleJoinAttempt = (codeOrUrl: string) => {
    const result = joinTripWithCode(codeOrUrl, currentUser);
    if (result.success && result.trip) {
      const updatedTrips = loadStoredTrips();
      setTrips(updatedTrips);
      setSelectedTripId(result.trip.id);
      setRefusalData(null);
      setActiveTab('detail');
      return result;
    } else {
      // Criterion F2-2: App shall refuse and show no trip details
      setSelectedTripId(null);
      setRefusalData({
        attemptedCode: codeOrUrl,
        errorMessage:
          result.error ||
          'Invite link is invalid or unrecognized. Access is refused and no trip details will be displayed (F2-2).',
      });
      setActiveTab('refusal');
      return result;
    }
  };

  const handlePostMoment = (caption: string, placeName?: string, imageUrl?: string) => {
    if (!selectedTripId || !currentUser) return;
    addMomentToTrip(selectedTripId, currentUser, caption, placeName, imageUrl);
    const updatedTrips = loadStoredTrips();
    setTrips(updatedTrips);
  };

  const handleSimulateJoinAsFriend = (friendName: string) => {
    if (!selectedTripId) return;
    const friendUser: User = {
      id: `user_${Date.now()}`,
      name: friendName,
      email: `${friendName.toLowerCase().replace(/\s+/g, '.')}@example.com`,
      roleDescription: 'Joined via reusable invite link',
      avatarColor: '#051E39',
    };
    const currentTrip = trips.find((t) => t.id === selectedTripId);
    if (!currentTrip) return;

    joinTripWithCode(currentTrip.inviteCode, friendUser);
    const updatedTrips = loadStoredTrips();
    setTrips(updatedTrips);
  };

  const handleOpenTrip = (trip: Trip) => {
    // Check if current user is a member
    if (currentUser) {
      const isMember = trip.members.some((m) => m.userId === currentUser.id);
      if (!isMember) {
        // F2-2: Refusal if not member and without invite
        setRefusalData({
          attemptedCode: 'Direct trip navigation without invite',
          errorMessage: `Access Refused: You are not a member of "${trip.name}". Trip details are protected and require a valid reusable invite link from the creator.`,
        });
        setSelectedTripId(null);
        setActiveTab('refusal');
        return;
      }
    } else {
      // Unsigned in user attempting to open trip without invite
      setRefusalData({
        attemptedCode: 'No Invite Provided',
        errorMessage:
          'Access Refused: You must possess a valid invite link to view trip details (F2-2).',
      });
      setSelectedTripId(null);
      setActiveTab('refusal');
      return;
    }

    setSelectedTripId(trip.id);
    setActiveTab('detail');
  };

  const handleResetData = () => {
    const { trips: resetTrips, user: resetUser } = resetToSeedData();
    setTrips(resetTrips);
    setCurrentUser(resetUser);
    setSelectedTripId(resetTrips[0]?.id || null);
    setRefusalData(null);
    setActiveTab('trips');
  };

  // Find currently selected trip
  const activeTrip = trips.find((t) => t.id === selectedTripId);

  return (
    <div className="min-h-screen bg-[#FFFFFF] text-[#1A1A1A] flex flex-col font-sans">
      {/* Global Header */}
      <Header
        currentUser={currentUser}
        onSelectUser={handleSelectUser}
        activeTab={activeTab === 'detail' || activeTab === 'refusal' ? 'trips' : activeTab}
        onNavigate={(tab) => {
          setRefusalData(null);
          setActiveTab(tab);
        }}
        onResetData={handleResetData}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-4 sm:p-6 space-y-6">
        {/* Testing Guide with verification triggers */}
        <TestingGuide
          onCreateTripTab={() => {
            setRefusalData(null);
            setActiveTab('create');
          }}
          onTriggerInvalidInvite={() => {
            handleJoinAttempt('FORGED-INVALID-LINK-999');
          }}
          onTriggerValidInvite={() => {
            if (trips.length > 0) {
              handleJoinAttempt(trips[0].inviteCode);
            } else {
              setActiveTab('create');
            }
          }}
        />

        {/* Dynamic Views */}
        {activeTab === 'refusal' && (
          <RefusalCard
            attemptedCode={refusalData?.attemptedCode}
            errorMessage={refusalData?.errorMessage}
            onRetryWithCode={(code) => handleJoinAttempt(code)}
            onGoBack={() => {
              setRefusalData(null);
              setActiveTab('trips');
            }}
          />
        )}

        {activeTab === 'create' && (
          <CreateTripForm
            currentUser={currentUser}
            onCreateTrip={handleCreateTrip}
            onGoToSignIn={() => {
              // Persona switcher prompt
            }}
          />
        )}

        {activeTab === 'join' && (
          <JoinTripForm
            currentUser={currentUser}
            availableTrips={trips}
            onJoinAttempt={handleJoinAttempt}
            onSuccessJoin={(trip) => {
              setSelectedTripId(trip.id);
              setActiveTab('detail');
            }}
            onGoToSignIn={() => {
              // Persona switcher
            }}
          />
        )}

        {activeTab === 'detail' && activeTrip && (
          <TripDetail
            trip={activeTrip}
            currentUser={currentUser}
            onPostMoment={handlePostMoment}
            onGoBack={() => setActiveTab('trips')}
            onSimulateJoinAsFriend={handleSimulateJoinAsFriend}
          />
        )}

        {activeTab === 'trips' && (
          <div className="space-y-6">
            {/* Context & Profile Summary */}
            <div className="bg-[#FFFFFF] border-2 border-[#B39051] rounded-[4px] p-6 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="text-[20px] font-bold text-[#051E39]">
                    Casual Travel Moments & Trips
                  </div>
                  <p className="text-[14px] text-[#1A1A1A]">
                    Designed for casual travelers who share real moments with friends in the moment, without the pressure or performative style of social media.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveTab('create')}
                  className="bg-[#051E39] text-[#FFFFFF] px-6 py-2 rounded-[4px] text-[14px] font-bold hover:bg-[#0a2f57] flex items-center gap-2 self-start sm:self-auto shrink-0"
                >
                  <Plus className="w-4 h-4 text-[#FFFFFF]" />
                  <span>Create New Trip</span>
                </button>
              </div>

              {/* Acceptance Criteria Status Indicator */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2 pt-2 border-t border-[#1A1A1A]/10">
                <div className="p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#1A1A1A]">
                  <strong className="text-[#051E39]">F2-1:</strong> Creator assigned & invite link given on creation.
                </div>
                <div className="p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#1A1A1A]">
                  <strong className="text-[#051E39]">F2-2:</strong> Invalid join refused; zero trip details shown.
                </div>
                <div className="p-2 border border-[#B39051] rounded-[4px] text-[14px] text-[#1A1A1A]">
                  <strong className="text-[#051E39]">F2-3:</strong> Each trip has one reusable invite link.
                </div>
              </div>
            </div>

            {/* Trips List */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="text-[18px] font-bold text-[#051E39]">
                  Available Trips ({trips.length})
                </div>
                <button
                  type="button"
                  onClick={() => setActiveTab('join')}
                  className="p-2 border border-[#B39051] rounded-[4px] text-[14px] font-bold text-[#051E39] hover:bg-[#FFFFFF] flex items-center gap-1"
                >
                  <KeyRound className="w-4 h-4 text-[#051E39]" />
                  Join with Link
                </button>
              </div>

              {trips.length === 0 ? (
                <div className="p-8 border border-[#B39051] rounded-[4px] text-center space-y-4 bg-[#FFFFFF]">
                  <div className="text-[16px] font-bold text-[#051E39]">
                    No trips created yet
                  </div>
                  <p className="text-[14px] text-[#1A1A1A]">
                    Create your first trip to become its creator and get a reusable invite link for your friends.
                  </p>
                  <button
                    type="button"
                    onClick={() => setActiveTab('create')}
                    className="bg-[#051E39] text-[#FFFFFF] px-6 py-2 rounded-[4px] text-[14px] font-bold hover:bg-[#0a2f57]"
                  >
                    Create a Trip Now
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-4">
                  {trips.map((trip) => (
                    <TripCard
                      key={trip.id}
                      trip={trip}
                      currentUser={currentUser}
                      onOpenTrip={handleOpenTrip}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-[#1A1A1A]/10 py-6 mt-12 bg-[#FFFFFF]">
        <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4 text-[14px] text-[#1A1A1A]/70">
          <div>
            TripTogether &bull; Private trip spaces for close travel companions
          </div>
          <div className="flex items-center gap-4">
            <span>Style Tokens: Arial &bull; Min 14px &bull; 8px Multiples &bull; 4px Radius</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
